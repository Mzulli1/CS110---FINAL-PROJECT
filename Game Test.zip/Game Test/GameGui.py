import pygame
import deck_updated
import random
from pygame.locals import *

pygame.init()
card_width = 160
card_height = 200
dist_wall = 20
dist_btwn = 100 + dist_wall + card_width

class Layer:
    def __init__(self):
        self.game_screen = pygame.display.set_mode([500, 500])




class Window:
    def __init__(self, screen):
        self.Screen = screen

    def get_backround(self, image):
        backround = pygame.image.load(image)
        backround_resize = pygame.transform.scale(backround, [500, 500])
        self.Screen.blit(backround_resize, [0, 0])


class Card(pygame.sprite.Sprite):
    # Constructor. Pass in the color of the block,
    # and its x and y position
    def __init__(self, filename, width, height):
        # Call the parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self)

        # Create an image of the block, and fill it with a color.
        # This could also be an image loaded from the disk.
        self.card = pygame.Surface([width, height])
        charRect = pygame.Rect((0, 0), (width, height))
        charImage = pygame.image.load(filename)
        charImage = pygame.transform.scale(charImage, charRect.size)
        charImage = charImage.convert()
        self.card.blit(charImage, charRect)
        

    def get_card(self):
        return self.card



class Deck:
    def __init__(self, screen):
        self.object_list = {}
        self.card_list = []
        self.cards_drawn = []
        self.cardplace = pygame.mixer.Sound('Casino Sound Package/cardPlace1.wav')
        for key in iter(deck_updated.VALUES):
            for card in iter(deck_updated.SUITS):
                i = key + card
                cardname = ('Card Images/%s.png' % i)
                self.card_list.append(cardname)
        random.shuffle(self.card_list)
        self.Screen = screen
        y = 20
        for card in self.card_list:
            placeholder = Card('red_back.png', card_width, card_height)
            self.object_list[card] = placeholder.get_card()
        for object_value in self.object_list:
            surface_needed = self.object_list[object_value]
            self.Screen.blit(surface_needed, (dist_wall, y))
            y += 2
        self.card_list.reverse()

    def draw_card(self):
        self.cardplace.stop()
        self.cardplace.play()
        self.top_deck = self.card_list[0]
        draw = Card(self.top_deck, card_width, card_height)
        self.cards_drawn.append(draw.card)
        self.card_list.pop(0)
        y = 20
        for object_value in self.card_list:
            surface_needed = self.object_list[object_value]
            self.Screen.blit(surface_needed, (dist_wall, y))
            y += 2
        g = 20
        for entries in self.cards_drawn:
            self.Screen.blit(entries, (dist_btwn, g))
            g += 2

blackjack = Layer()
pokertable = 'backround.jpg'
game = Window(blackjack.game_screen)
game.get_backround(pokertable)
deck_1 = Deck(blackjack.game_screen)
y = 0
while deck_1.card_list:
    pressed = pygame.mouse.get_pressed()
    if pressed[0] != 0:
        game.get_backround(pokertable)
        deck_1.draw_card()
    pygame.event.get()
    pygame.display.flip()
